package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var me: EditText? = null
    private var Button: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        me = findViewById(R.id.me)
        Button = findViewById(R.id.button)
        Button.setOnClickListener(View.OnClickListener {
            val textToPass = me.getText().toString()
            val intent = Intent(this@activity_main, Activity_main3::class.java)
            intent.putExtra("texto para el main", textToPass)
            startActivity(intent)
        })
    }
}